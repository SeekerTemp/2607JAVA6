# Lab 8 — Ghi chú realtime (Spring Boot + Vue)

## Backend (`backend/`)

Layered as requested: `entity` → `repository` → `service` → `controller`, plus `config` for WebSocket/CORS.

- `Note` (entity) mirrors the schema from **request_labs8.2**: `id, author, content, created_at, updated_at`.
- `NoteRepository` — Spring Data JPA.
- `NoteService` — business logic; on `createNote` it saves via the repository **and** broadcasts the saved note to `/topic/notes` over STOMP.
- `NoteController` — `/api/notes` REST endpoints (GET all, GET by id, POST, PUT, DELETE) exactly per **request_labs8.2**.
- `WebSocketConfig` — STOMP endpoint at `/ws` (SockJS), broker prefix `/topic`.
- Storage: H2 in-memory (matches the comment already in your `pom.xml` — swap the datasource in `application.properties` for real SQL Server later if needed, the entity/table shape already matches the `NotesDB.Notes` schema).

Run:
```bash
cd backend
mvn spring-boot:run
```
Backend comes up on `http://localhost:8080`. Seed rows (Trung/Lan/Bảo) load automatically from `data.sql`.

## Frontend (`frontend-additions/`)

Drop these into your existing `l8-fe` project (same relative paths: `src/App.vue`, `src/services/notesApi.js`, `src/services/notesSocket.js`).

Install the two extra deps it needs:
```bash
cd l8-fe
npm install axios sockjs-client @stomp/stompjs
npm run dev
```

`App.vue` is intentionally a single simple component:
- two inputs (author, content) + a send button/Enter
- `POST /api/notes` on send, then clears the content input
- subscribes to `/topic/notes` over WebSocket on mount and prepends every incoming note to the list — this is also how the sender's own note shows up, so all connected clients (including yourself) stay in sync through the same code path
- list shows author, content, and formatted time, newest first

If your Vue dev server isn't on `http://localhost:5173` (Vite default), note that `CorsConfig.java` in the backend currently allows any `http://localhost:*` origin, so that should already cover most setups — tighten it once you know your real dev port.
